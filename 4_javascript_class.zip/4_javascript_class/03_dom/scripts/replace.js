
// window.onload = function(){	
		
  var list = document.getElementById('list');
  var pic = document.getElementById('pic');
  var del = document.getElementById('del');

  // 리스트에서 선택(클릭했을 때)


  
  // 삭제 버튼 누르면 pic 아래 자식(img 태그)를 지운다
  
  
  
//};
